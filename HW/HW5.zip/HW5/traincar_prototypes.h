// =======================================================================
//
// IMPORTANT NOTE: You should edit this file
//                 This file is #include'd from traincar.h and main.cpp
//
// =======================================================================
//
// There are a number of additional functions used in main.cpp that
// you need to declare and implement.  Study main.cpp and the provided
// output to determine the arguments, return type, and overall
// behavior.
//
// Add all required additional function prototypes here
// (you may also add your own helper function prototypes here too)
//
// Implement these functions in "traincar.cpp"
//

//Deletes the nodes to the train/cars
void DeleteAllCars(TrainCar* t);

//essentially appends a value to the end
void PushBack(TrainCar* &t, TrainCar* x);

//calculates the horsepower
int getHorse(TrainCar* t);

//calculates the total weight
int getTotalWeight(TrainCar* t);

float CalculateSpeed(TrainCar* t);

//Calculates the average distance from passenger cars to dining cars
float AverageDistanceToDiningCar(TrainCar* t);

//Calculates the average distance from Engine to Sleeper cars.
int ClosestEngineToSleeperCar(TrainCar* t);

void TotalWeightAndCountCars(TrainCar* t, int& tweight, int& engines, int& numFreight,
   int& numPassenger, int& numDining, int& numSleeping);

std::vector ShipFreight(TrainCar* eng, TrainCar* freight, int minSpeed, int maxCars);
