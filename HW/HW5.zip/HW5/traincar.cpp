// =======================================================================
//
// IMPORTANT NOTE: You should edit this file
//
// =======================================================================

#include <iostream>
#include <iomanip>
#include <string>
#include <cassert>
#include <cmath>
#include <cstdlib>
#include <vector>

#include "traincar.h"

// =======================================================================
// =======================================================================
//
//  HERE'S WHERE YOU SHOULD IMPLEMENT THE FUNCTIONS YOU PROTOTYPED IN
//  THE "TrainCar_prototypes.h" FILE.
//

void DeleteAllCars(TrainCar* t)
{
  TrainCar* tmp;
  while(t)
  {
    tmp = t->next;
    delete t;
    t = tmp;
  }
}

void PushBack(TrainCar* &t, TrainCar* x)
{
  //if x has a previous, go to farthest previous (just a thought)

  //two cases
  //1. train already has values in it.
  //2. train has nothing
  TrainCar* tail = t;

  if(!t)
  {
    t = x;
    return;
  }

  while(tail->next)
    tail = tail->next;

  tail->next = x;
  x->prev = tail;
}

int getHorse(TrainCar* t)
{
  int totalHorse = 0;
  TrainCar* tmp = t;
  while(tmp)
  {
    if(tmp->isEngine())
      totalHorse += 3000;
    tmp = tmp->next;
  }
  return totalHorse;
}

int getTotalWeight(TrainCar* t)
{
  int totalWeight = 0;
  TrainCar* tmp = t;
  while(tmp)
  {
    if(tmp->isEngine())
      totalWeight += 150;
    else
      totalWeight += 50;
    tmp = tmp->next;
  }
  return totalWeight;
}

float CalculateSpeed(TrainCar* t)
{
  int horse = getHorse(t);
  float top = (horse * 550.0 * 3600.0);
  float bottom = (20/0.01) * 0.02 * 5280 * getTotalWeight(t);
  return top/bottom;
}

float AverageDistanceToDiningCar(TrainCar* t)
{
  //eventually divide by the amount of passenger cars.
  //overall temporary pointer, temporary right pointer and temporary left pointer, respectively.
  TrainCar* tmp = t;
  TrainCar* tmpright;
  TrainCar* tmpleft;
  //average distances
  float avg = 0.0;
  //total distances passenger cars are from dining halls.
  int totalDist = 0;
  //total number of passenger cars.
  int numPassCars = 0;
  //distance to the right counter
  int distRight = 0;
  //distance to the left counter
  int distLeft = 0;
  //basically keep going through passenger cars until null (none left)
  while(tmp)
  {
    //begin analysis if on a passenger car.
    if(tmp->isPassengerCar())
    {
      tmpright = tmp;
      tmpleft = tmp;
      while(tmpright && !tmpright->isDiningCar())
      {
        if(tmpright->isEngine())
        {
          //-1 because it hits an engine.
          distRight = 9999;
          break;
        }
        if(!tmpright)
          break;
        distRight++;
        tmpright = tmpright->next;
      }
      while(tmpleft && !tmpleft->isDiningCar())
      {
        if(tmpleft->isEngine())
        {
          //-1 because it hits an engine.
          distLeft = 9999;
          break;
        }
        if(!tmpleft)
          break;

        distLeft++;
        tmpleft = tmpleft->prev;
      }
      //determining which one (left or right) is closer to a dining hall
      if(distLeft <= distRight)
        totalDist += distLeft;
      else
        totalDist += distRight;
      //if passenger car add to total count
      numPassCars++;

      //reset values (can't use list to store multiple vals)
      distLeft = 0;
      distRight = 0;
    }
    tmp = tmp->next;
  }
  //Calculate the averages
  avg = float(totalDist)/float(numPassCars);
  return avg;
}

int ClosestEngineToSleeperCar(TrainCar* t)
{
  //overall temporary pointer, temporary right pointer and temporary left pointer, respectively.
  TrainCar* tmp = t;
  TrainCar* tmpright;
  TrainCar* tmpleft;
  //set closest to some arbitrarily large number so it changes
  int closest = 9999;

  while(tmp)
  {
    int rightCount = 0;
    int leftCount = 0;
    if(tmp->isSleepingCar())
    {
      tmpright = tmp;
      tmpleft = tmp;
      while(tmpright && !tmpright->isEngine())
      {
        rightCount++;
        tmpright = tmpright->next;
      }
      if(!tmpright)
        rightCount = 9999;
      while(tmpleft && !tmpleft->isEngine())
      {
        leftCount++;
        tmpleft = tmpleft->prev;
      }
      if(!tmpleft)
        leftCount = 9999;
    }
    if(rightCount <= leftCount && rightCount < closest && rightCount != 0)
      closest = rightCount;

    else if(leftCount < rightCount && leftCount < closest && leftCount != 0)
      closest = leftCount;

    tmp = tmp->next;
  }
  if(closest == 9999)
    closest = -1;
  return closest;
}

void TotalWeightAndCountCars(TrainCar* t, int& total_weight, int& num_engines, int& num_freight,
   int& num_passenger, int& num_dining, int& num_sleeping)
   {
     total_weight = 0;
     num_engines = 0;
     num_freight = 0;
     num_passenger = 0;
     num_dining = 0;
     num_sleeping = 0;
     TrainCar* tmp = t;
     //looping over entire train, adding to total_weight and other counters.

     while(tmp)
     {
       if(tmp->isEngine())
       {
         num_engines++;
       }
       else if(tmp->isFreightCar())
       {
         num_freight++;
       }
       else if(tmp->isPassengerCar())
       {
         num_passenger++;
       }
       else if(tmp->isDiningCar())
       {
         num_dining++;
       }
       else if(tmp->isSleepingCar())
       {
         num_sleeping++;
       }
       total_weight += tmp->getWeight();
      tmp = tmp->next;
     }
   }

std::vector<TrainCar*> ShipFreight(TrainCar* eng, TrainCar* freight, int minSpeed, int maxCars)
{
  std::vector<TrainCar*> sumTrains;

  TrainCar* f = freight;
  TrainCar* e = eng;
  TrainCar* head = NULL;
  //Keep track of all of the statistics of the trains
  int numEngines = 0;
  int numCars = 0;
  int weightFreights = 0;
  int weightEngines = 0;
  int totalWeight = 0;
  int initialHorse = 0;

  float tmpSpeed = 999999.0;
  //TrainCar pointer that points to the remainder of the list of cars
  TrainCar* tmp;

  //calculate the total freight weight
  while(f)
  {
    weightFreights += f->getWeight();
    f = f->next;
  }
  //Calculate the total engine weight
  while(e)
  {
    weightEngines += 150
    e = e->next;
  }
  //Calculate the total weight
  totalWeight = weightEngines + weightFreights;

  //store the total horsepower at disposal initially
  initialHorse = getHorse(eng);

  //store the initial speed of 1 engine
  float top = 3000 * 550.0 * 3600.0);
  float bottom = (20/0.01) * 0.02 * 5280 * 150;
  initialSpeed = top/bottom;

  if()
  //weight of freights
  while(f)
    if(minSpeed < currentSpeed && tmpSpeed > initialSpeed)
    {
      float top = (3000 * 550.0 * 3600.0);
      float bottom = (20/0.01) * 0.02 * 5280 * totalWeight+f;
      currentSpeed = top/bottom;

    }
    f = f->next;
  }

}
